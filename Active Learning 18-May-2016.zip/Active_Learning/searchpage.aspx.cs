﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class searchpage : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["privacy"].ToString());
    SqlDataAdapter da;
    SqlCommand cmd;
    DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["searchkey"] != null)
        {
            txtsearch.Text = Session["searchkey"].ToString();
            Session["searchkey"] = null;
        }

        if (txtsearch.Text.Length > 0)
        {
            List<string> catlst = new List<string>();
            List<string> datalst = new List<string>();
            List<string> Rstlst = new List<string>();
            DataTable Fdt = new DataTable();
            if (con.State == ConnectionState.Closed)
                con.Open();
            da = new SqlDataAdapter("select c.urlname,c.category,c.title,c.description,c.pic,l.cnt from content c inner join (select urlname,uid,count(*) cnt from log group by urlname,uid) l on c.urlname = l.urlname where c.urlname like '%" + txtsearch.Text + "%' order by l.cnt Desc", con);
            dt = new DataTable();
            da.Fill(dt);

            da = new SqlDataAdapter("select top 2 category,Count(*) cnt from content where urlname like '%" + txtsearch.Text + "%' group by category order by cnt DESC", con);
            DataTable tmp = new DataTable();
            da.Fill(tmp);
            Fdt = dt.Clone();
            if (tmp.Rows.Count > 0)
            {
                catlst.Add(tmp.Rows[0]["category"].ToString());

                if (tmp.Rows.Count > 1)
                {
                    catlst.Add(tmp.Rows[1]["category"].ToString());
                }

                foreach (string st in catlst)
                {
                    var drr = from s in dt.AsEnumerable() where s.Field<string>("category") == st select s;

                    foreach (DataRow dr1 in drr)
                    {
                        Fdt.Rows.Add(dr1);
                    }
                }

                cmd = new SqlCommand("insert into LossFactor(Search,found,removed,uid) values('" + txtsearch.Text + "','" + dt.Rows.Count + "','" + (dt.Rows.Count - Fdt.Rows.Count) + "', " + Session["id"].ToString() + ")", con);
                cmd.ExecuteNonQuery();
            }
            else
            {
                Fdt = dt;
            }

            DataList1.DataSource = Fdt;
            DataList1.DataBind();



            string category = dt.Rows[0]["category"].ToString();

            cmd = new SqlCommand("select urlname from log where uid=" + Session["id"].ToString(), con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
                while (dr.Read())
                {
                    datalst.Add(dr.GetString(0));
                }
            dr.Close();
            int i = 0;
            string toserach = "";
            foreach (string st in datalst)
            {
                if (i < datalst.Count && st.ToUpper() != txtsearch.Text.ToUpper())
                {
                    if (toserach.Length == 0)
                        toserach = "'" + datalst[i++] + "'";
                    else
                        toserach += ",'" + datalst[i++] + "'";
                }
            }

            if (toserach != "")
            {
                da = new SqlDataAdapter("select * from Website where urlname in (" + toserach + ")", con);
                dt = new DataTable();
                da.Fill(dt);
                DataList2.DataSource = dt;
                DataList2.DataBind();
            }

            da = new SqlDataAdapter("select Top 1 * from content where category='" + category + "' order by (datee) desc", con);
            dt = new DataTable();
            da.Fill(dt);
            DataList3.DataSource = dt;
            DataList3.DataBind();


            //cmd = new SqlCommand("insert into log(urlname,uid) values('" + txtsearch.Text + "', " + Session["id"].ToString() + ")", con);
            //cmd.ExecuteNonQuery();
            txtsearch.Text = "";
            if (con.State == ConnectionState.Open)
                con.Close();
        }
    }
    protected void itemcommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName.Equals("lnk1"))
        {
            Response.Redirect("ResultPage.aspx");
        }
    }
    protected void link1_Click(object sender, EventArgs e)
    {
        Button btn = sender as Button;

        if (con.State == ConnectionState.Closed)
            con.Open();
        cmd = new SqlCommand("insert into log(urlname,uid) values('" + btn.Text + "', " + Session["id"].ToString() + ")", con);
        cmd.ExecuteNonQuery();
        if (con.State == ConnectionState.Open)
            con.Close();

        DownloadFile(Server.MapPath("~/Doc/") + btn.Text);
    }

    public void DownloadFile(string strURL)
    {
        WebClient req = new WebClient();
        HttpResponse response = HttpContext.Current.Response;
        response.Clear();
        response.ClearContent();
        response.ClearHeaders();
        response.Buffer = true;
        response.AddHeader("Content-Disposition", "attachment;filename=\"" + strURL + "\"");
        byte[] data = req.DownloadData(strURL);
        response.BinaryWrite(data);
        response.End();
    }
}