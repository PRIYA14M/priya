﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registeration : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["privacy"].ToString());
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void regis_Click(object sender, EventArgs e)
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        cmd = new SqlCommand("insert into profile(uname,password,email,location,datee) values ('" + txtusname.Text + "','" + txtpass.Text + "','" + txtmail.Text + "','" + txtloc.Text + "','" + DateTime.Now.ToString() + "')", con);
        if (cmd.ExecuteNonQuery() > 0)
            Response.Write("<script>alert('Added Successfully')</script>");
        if (con.State == ConnectionState.Open)
            con.Close();
    }
}