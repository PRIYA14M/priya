﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Addwebcontent : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["privacy"].ToString());
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void add_content_Click(object sender, EventArgs e)
    {
        string filename = System.IO.Path.GetFileName(FileUpload1.FileName);
        FileUpload1.SaveAs(Server.MapPath("~/img/") + filename);


        string Docname = System.IO.Path.GetFileName(flpdoc.FileName);
        flpdoc.SaveAs(Server.MapPath("~/Doc/") + Docname);

        if (con.State == ConnectionState.Closed)
            con.Open();
        cmd = new SqlCommand("insert into content(urlname,category,title,description,datee,pic) values('" + Docname + "','" + txt_cat.Text + "','" + txt_title.Text + "','" + txt_desc.Text + "','" + DateTime.Now.ToString() + "','" + filename + "')", con);
        if (cmd.ExecuteNonQuery() > 0)
            Response.Write("<script>alert('Added Successfully')</script>");
        if (con.State == ConnectionState.Open)
            con.Close();
    }
}