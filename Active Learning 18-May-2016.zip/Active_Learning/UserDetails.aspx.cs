﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserDetails : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["privacy"].ToString());
    SqlDataAdapter da;
    SqlCommand cmd;
    DataTable dt;
    string str;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        str = "select * from profile";
        da = new SqlDataAdapter(str, con);
        dt = new DataTable();
        da.Fill(dt);

        GridView1.DataSource = dt;

        GridView1.DataBind();
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        str = "select * from content";
        da = new SqlDataAdapter(str, con);
        dt = new DataTable();
        da.Fill(dt);

        GridView1.DataSource = dt;

        GridView1.DataBind();
    }
}