﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Graph : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    [WebMethod]
    public static object GetHis()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["privacy"].ToString());
        List<RootObject> lst = new List<RootObject>();
        List<RootObject> lst1 = new List<RootObject>();
        RootObject l;
        SqlDataAdapter da = new SqlDataAdapter("SELECT Search,found,removed FROM LossFactor where uid =" + HttpContext.Current.Session["id"].ToString(), con);
        DataTable dt = new DataTable();
        da.Fill(dt);

        foreach(DataRow dr in dt.Rows)
        {
            l = new RootObject();
            l.label = dr["Search"].ToString();
            l.y = Convert.ToInt32(dr["found"].ToString());

            lst.Add(l);


            l = new RootObject();
            l.label = dr["Search"].ToString();
            l.y = Convert.ToInt32(dr["removed"].ToString());

            lst1.Add(l);
        }

        var t = new
        {
            T1=lst,
            T2=lst1
        };

        return t;
    }
}

public class RootObject
{
    public string label { get; set; }
    public int y { get; set; }
}