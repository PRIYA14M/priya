﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["privacy"].ToString());
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnlgn_Click(object sender, EventArgs e)
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        if (txtusname.Text.ToLower() == "admin" && txtpwd.Text == "admin")
            Response.Redirect("Addweburl.aspx");
        cmd = new SqlCommand("select ID from profile where uname='" + txtusname.Text + "' and password='" + txtpwd.Text + "'", con);
        int id = Convert.ToInt32(cmd.ExecuteScalar());
        if (id > 0)
        {
            Session["usname"] = txtusname.Text;
            Session["pwd"] = txtpwd.Text;
            Session["id"] = id;
            cmd = new SqlCommand("delete from log where uid=" + Session["id"].ToString(), con);
            cmd.ExecuteNonQuery();
            Response.Redirect("searchpage.aspx");
        }
        else
            Response.Write("<script>alert('User Details mis-match')</script>");
        if (con.State == ConnectionState.Open)
            con.Close();
    }
    protected void btnregis_Click(object sender, EventArgs e)
    {
        Response.Redirect("Registeration.aspx");
    }
}