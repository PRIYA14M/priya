﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ActiveLearn : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string currentPage = System.IO.Path.GetFileName(Request.Url.AbsolutePath);
        if (currentPage != "Default.aspx" && currentPage != "Homepage.aspx" && currentPage != "Registeration.aspx")
        {
            if (currentPage == "searchpage.aspx")
            {
                mnusr.Visible = true;
                mnadmin.Visible = false;
            }
            else
            {
                mnusr.Visible = false;
                mnadmin.Visible = true;
            }
        }
    }
}
